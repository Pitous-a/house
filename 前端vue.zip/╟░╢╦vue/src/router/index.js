import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

/* Layout */
import Layout from '@/layout'
import { getToken } from '@/utils/auth'

/**
 * Note: sub-menu only appear when route children.length >= 1
 * Detail see: https://panjiachen.github.io/vue-element-admin-site/guide/essentials/router-and-nav.html
 *
 * hidden: true                   if set true, item will not show in the sidebar(default is false)
 * alwaysShow: true               if set true, will always show the root menu
 *                                if not set alwaysShow, when item has more than one children route,
 *                                it will becomes nested mode, otherwise not show the root menu
 * redirect: noRedirect           if set noRedirect will no redirect in the breadcrumb
 * name:'router-name'             the name is used by <keep-alive> (must set!!!)
 * meta : {
    roles: ['admin','editor']    control the page roles (you can set multiple roles)
    title: 'title'               the name show in sidebar and breadcrumb (recommend set)
    icon: 'svg-name'/'el-icon-x' the icon show in the sidebar
    breadcrumb: false            if set false, the item will hidden in breadcrumb(default is true)
    activeMenu: '/example/list'  if set path, the sidebar will highlight the path you set
  }
 */

/**
 * constantRoutes
 * a base page that does not have permission requirements
 * all roles can be accessed
 */
export const constantRoutes = [
  {
    path: '/login',
    component: () => import('@/views/login/index'),
    hidden: true
  },
  //修改密码
  {
    path: '/alterpassword',
    hidden: true,
    component: () => import('@/views/other/alterpassword'),
    meta: { title: '修改密码', icon: 'form' }
  },
  {
    path: '/404',
    component: () => import('@/views/404'),
    hidden: true
  },

  //首页
  {
    path: '/',
    component: Layout,
    redirect: '/dashboard',
    children: [{
      path: 'dashboard',
      name: 'Dashboard',
      component: () => import('@/views/dashboard/index'),
      meta: { title: '首页', icon: 'dashboard' }
    }]
  },

  //个人信息
  // {
  //   path: '/info',
  //   component: Layout,
  //   children: [{
  //     path: 'info',
  //     name: 'Info',
  //     component: () => import('@/views/other/info'),
  //     meta: { title: '个人信息', icon: 'dashboard' }
  //   }]
  // },

  //聊天
  {
    path: '/message',
    component: Layout,
    name: 'Message',
    meta: { title: '消息通知', icon: 'el-icon-s-help' },
    children: [
      {
        path: 'imui',
        name: 'IMUI',
        component: () => import('@/views/message/message'),
        meta: { title: '聊天室', icon: 'table' }
      },
    ]
  },

  //前台
  {
    path: '/front',
    component: Layout,
    hidden: getToken() !== '前台',
    meta: {
      title: '注册',
      icon: 'nested'
    },
    children: [
      {
        path: 'newemployee',
        name: 'Newemployee',
        component: () => import('@/views/front/newemployee'),
        meta: { title: '注册员工信息', icon: 'form' }
      },
      {

        path: 'newclient',
        name: 'Newclient',
        component: () => import('@/views/front/newclient'),
        meta: { title: '注册客户信息', icon: 'form' }

      },
    ]
  },

  //员工
  {
    path: '/employee',
    component: Layout,
    hidden: (getToken() !== '新手') && (getToken() !== '熟手'),
    meta: {
      title: '项目查看',
      icon: 'nested'
    },
    children: [
      {
        path: 'myproject',
        name: 'Myproject',
        component: () => import('@/views/employee/myproject'),
        meta: { title: '我的项目', icon: 'form' },

      },
      {
        hidden: true,
        path: 'project',
        name: 'Project',
        component: () => import('@/views/employee/project'),
        meta: { title: '项目信息', icon: 'form' },
      },
      {
        path: 'search_customer',
        name: 'Search_customer',
        component: () => import('@/views/director/search_customer'),
        meta: { title: '客户查询', icon: 'form' }
      },
    ]
  },

  //主管
  {
    path: '/director',
    component: Layout,
    hidden: (getToken() !== '模型主管') && (getToken() !== '后期主管')
      && (getToken() !== '渲染主管'),
    meta: {
      title: '项目管理',
      icon: 'nested'
    },
    children: [
      {
        hidden: getToken() !== '模型主管',
        path: 'newproject',
        name: 'Newproject',
        component: () => import('@/views/director/newproject'),
        meta: { title: '新建项目', icon: 'form' }
      },
      {
        path: 'myproject',
        name: 'Myproject',
        component: () => import('@/views/director/myproject'),
        meta: { title: '我的项目', icon: 'form' },

      },
      {
        hidden: true,
        path: 'project',
        name: 'Project',
        component: () => import('@/views/director/project'),
        meta: { title: '项目信息', icon: 'form' },
      },
      {
        path: 'search_customer',
        name: 'Search_customer',
        component: () => import('@/views/director/search_customer'),
        meta: { title: '客户查询', icon: 'form' }
      },
    ]
  },

  //老板
  {
    path: '/boss1',
    component: Layout,
    hidden: getToken() !== '老板',
    meta: {
      title: '项目管理',
      icon: 'nested'
    },
    children: [
      {
        path: 'allproject',
        name: 'Allproject',
        component: () => import('@/views/boss/allproject'),
        meta: { title: '项目信息', icon: 'form' },

      },
      {
        hidden: true,
        path: 'project',
        name: 'Project',
        component: () => import('@/views/boss/project'),
        meta: { title: '编辑项目', icon: 'form' },
      },
      {
        path: 'newproject',
        name: 'Newproject',
        component: () => import('@/views/boss/newproject'),
        meta: { title: '新建项目', icon: 'form' }
      },
    ]
  },

  {
    path: '/boss2',
    component: Layout,
    hidden: getToken() !== '老板',
    meta: {
      title: '员工管理',
      icon: 'nested'
    },
    children: [
      {
        path: 'allemployee',
        name: 'Allemployee',
        component: () => import('@/views/boss/allemployee'),
        meta: { title: '员工信息', icon: 'form' }
      },
      {
        path: 'newemployee',
        name: 'Newemployee',
        component: () => import('@/views/boss/newemployee'),
        meta: { title: '注册员工', icon: 'form' },

      },
      {
        hidden: true,
        path: 'employee',
        name: 'Employee',
        component: () => import('@/views/boss/employee'),
        meta: { title: '编辑员工', icon: 'form' },
      },
    ]
  },

  {
    path: '/boss3',
    component: Layout,
    hidden: getToken() !== '老板',
    meta: {
      title: '客户管理',
      icon: 'nested'
    },
    children: [
      {
        path: 'allclient',
        name: 'Allclient',
        component: () => import('@/views/boss/allclient'),
        meta: { title: '客户信息', icon: 'form' }
      },
      {
        path: 'newclient',
        name: 'Newclient',
        component: () => import('@/views/boss/newclient'),
        meta: { title: '注册客户', icon: 'form' },

      },
      {
        hidden: true,
        path: 'client',
        name: 'Client',
        component: () => import('@/views/boss/client'),
        meta: { title: '编辑客户', icon: 'form' },
      },
    ]
  },

  // 404 page must be placed at the end !!!
  { path: '*', redirect: '/404', hidden: true }
]

const createRouter = () => new Router({
  mode: 'history', // require service support
  scrollBehavior: () => ({ y: 0 }),
  routes: constantRoutes
})

const router = createRouter()

// Detail see: https://github.com/vuejs/vue-router/issues/1234#issuecomment-357941465
export function resetRouter() {
  const newRouter = createRouter()
  router.matcher = newRouter.matcher // reset router
}

export default router
