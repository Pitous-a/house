<template>
  <div class="app-container">
    <el-form ref="form" :model="form" label-width="120px">
      <el-form-item label="员工编号">
        <el-input v-model="form.employee_id" />
      </el-form-item>
      <el-form-item label="员工姓名">
        <el-input v-model="form.employee_name" />
      </el-form-item>
      <el-form-item label="年龄">
        <el-input v-model="form.employee_age" />
      </el-form-item>
      <el-form-item label="部门">
        <el-select v-model="form.department" placeholder="请选择">
          <el-option label="主管部" value="主管部" />
          <el-option label="建模部" value="建模部" />
          <el-option label="渲染部" value="渲染部" />
          <el-option label="后期部" value="后期部" />
          <el-option label="办公室" value="办公室" />
        </el-select>
      </el-form-item>
      <el-form-item label="联系方式">
        <el-input v-model="form.employee_tele" />
      </el-form-item>

      <el-form-item label="职务">
        <el-select v-model="form.employee_office" placeholder="请选择">
          <el-option label="新手" value="新手" />
          <el-option label="熟手" value="熟手" />
          <el-option label="前台" value="前台" />
          <el-option label="模型主管" value="模型主管" />
          <el-option label="渲染主管" value="渲染主管" />
          <el-option label="后期主管" value="后期主管" />
          <el-option label="老板" value="老板" />
        </el-select>
      </el-form-item>
      <!-- <el-form-item label="Activity time">
        <el-col :span="11">
          <el-date-picker v-model="form.date1" type="date" placeholder="Pick a date" style="width: 100%;" />
        </el-col>
        <el-col :span="2" class="line">-</el-col>
        <el-col :span="11">
          <el-time-picker v-model="form.date2" type="fixed-time" placeholder="Pick a time" style="width: 100%;" />
        </el-col>
      </el-form-item>
      <el-form-item label="Instant delivery">
        <el-switch v-model="form.delivery" />
      </el-form-item>
      <el-form-item label="Activity type">
        <el-checkbox-group v-model="form.type">
          <el-checkbox label="Online activities" name="type" />
          <el-checkbox label="Promotion activities" name="type" />
          <el-checkbox label="Offline activities" name="type" />
          <el-checkbox label="Simple brand exposure" name="type" />
        </el-checkbox-group>
      </el-form-item>
      <el-form-item label="Resources">
        <el-radio-group v-model="form.resource">
          <el-radio label="Sponsor" />
          <el-radio label="Venue" />
        </el-radio-group>
      </el-form-item>
      <el-form-item label="Activity form">
        <el-input v-model="form.desc" type="textarea" />
      </el-form-item> -->
      <el-form-item label="账号">
        <el-input v-model="form.username" value="form.employee_name" />
      </el-form-item>
      <el-form-item label="密码">
        <el-input v-model="form.password" />
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="onSubmit">创建</el-button>
        <el-button @click="onCancel">取消</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
export default {
  data() {
    return {
      form: {
        employee_id: null,
        employee_name: "",
        employee_age: "",
        department: "",
        employee_tele: "",
        employee_office: "",
        username: "",
        password: "123",
      },
    };
  },
  methods: {
    onSubmit() {
      this.$axios
        .post("/all/newemployee", this.form)
        .then((resp) => {
          if (resp.data.state === "yes") this.$message.success("提交成功！");
          else {
            this.$message.error("提交失败！");
          }
        })
        .catch((e) => this.$message.error("提交失败！"));
    },
    onCancel() {
      this.$message({
        message: "已取消",
        type: "warning",
      });
    },
  },
  mounted() {
    let employee = JSON.parse(localStorage.getItem("logindata")).employee;
    this.form.my_id = employee.employee_id;
    this.form.my_name = employee.employee_name;
    this.form.my_office = employee.employee_office;
  },
};
</script>

<style scoped>
.line {
  text-align: center;
}
</style>

