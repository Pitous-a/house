<template>
  <el-table
    :loading="loading"
    :data="
      tableData.filter(
        (data) =>
          !search ||
          data.project_name.toLowerCase().includes(search.toLowerCase())
      )
    "
    style="width: 100%"
  >
    <el-table-column label="创建日期" prop="project_begindate" sortable>
    </el-table-column>

    <el-table-column label="项目名称" prop="project_name" sortable>
    </el-table-column>

    <el-table-column label="项目状态" prop="project_state" sortable>
    </el-table-column>

    <el-table-column align="right" label="操作">
      <!-- <template slot="header" slot-scope="scope">
        <el-input v-model="search" size="mini" placeholder="输入关键字搜索" />
      </template> -->
      <template slot-scope="scope">
        <el-button size="mini" type="primary" @click="detail(scope.$index)"
          >详细信息</el-button
        >
      </template>
    </el-table-column>
  </el-table>
</template>

<script>
export default {
  data() {
    return {
      turn: true,
      loading: true,
      tableData: [
        {
          project_id: null,
          project_name: "",
          project_begindate: null,
          project_period: "",
          project_price: null,
          project_enddate: null,
          project_periodstage: "",
          project_type: "",
          project_state: "",
          amendments: "",
        },
        {
          project_id: 1,
          project_name: "cw",
          project_begindate: "2020-17-5",
          project_period: "",
          project_price: null,
          project_enddate: null,
          project_periodstage: "",
          project_type: "",
          project_state: "新建",
          amendments: "",
        },
        {
          project_id: 5,
          project_name: "csfb",
          project_begindate: "2021-17-5",
          project_period: "",
          project_price: null,
          project_enddate: null,
          project_periodstage: "",
          project_type: "",
          project_state: "新建",
          amendments: "",
        },
      ],
      search: "",
    };
  },
  methods: {
    detail(index) {
      this.$router.push({ path: "/director/project" });
      localStorage.setItem("project", JSON.stringify(this.tableData[index]));
      this.turn = true;
    },
  },
  created() {
    let employee = JSON.parse(localStorage.getItem("logindata")).employee;
    this.$axios
      .post("/all/allproject", {
        my_id: employee.employee_id,
        my_name: employee.employee_name,
        my_office: employee.employee_office,
      })
      .then((resp) => {
        this.tableData = resp.data.allproject;
      })
      .catch((e) => console.log("post失败"));
  },
};
</script>
<style>
.demo-table-expand {
  font-size: 0;
}
.demo-table-expand label {
  width: 100px;
  color: #99a9bf;
}
.demo-table-expand .el-form-item {
  margin-right: 0;
  margin-bottom: 0;
  width: 50%;
}
</style>