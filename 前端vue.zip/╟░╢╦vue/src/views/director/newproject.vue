<template>
  <div class="app-container">
    <el-form ref="form" :model="form" label-width="120px">
      <el-form-item label="选择客户单位">
        <el-cascader
          v-model="value"
          :options="options"
          :props="{ expandTrigger: 'hover' }"
          @change="search_client"
        ></el-cascader>
      </el-form-item>

      <el-form-item label="选择客户">
        <el-select placeholder="请选择" v-model="customer">
          <el-option
            v-for="item in customer_list"
            :key="item"
            :label="item"
            :value="item"
          >
          </el-option>
        </el-select>
      </el-form-item>


      <el-form-item label="项目编号">
        <el-input v-model="form.project_id" />
      </el-form-item>
      <el-form-item label="项目名称">
        <el-input v-model="form.project_name" />
      </el-form-item>
      <el-form-item label="创建日期">
        <el-col :span="11">
          <el-date-picker
            disabled
            v-model="form.project_begindate"
            type="date"
            style="width: 100%"
          />
        </el-col>
      </el-form-item>

      <el-form-item label="项目阶段">
        <el-select v-model="form.project_period" placeholder="请选择">
          <el-option label="建模" value="建模" />
          <el-option label="渲染" value="渲染" />
          <el-option label="后期" value="后期" />
        </el-select>
      </el-form-item>

      <el-form-item label="项目报价">
        <el-input v-model="form.project_price" />
      </el-form-item>
      <el-form-item label="项目类型">
        <el-select v-model="form.project_type" placeholder="请选择">
          <el-option label="楼盘效果图设计" value="楼盘效果图设计" />
          <el-option label="商场效果图设计" value="商场效果图设计" />
          <el-option label="车站效果图设计" value="车站效果图设计" />
          <el-option label="厂房效果图设计" value="厂房效果图设计" />
          <el-option label="其他效果图设计" value="其他效果图设计" />
        </el-select>
      </el-form-item>

      <el-form-item label="项目状态">
        <el-select v-model="form.project_state" placeholder="请选择" disabled>
          <el-option label="新建" value="新建" />
          <el-option label="正在执行" value="正在执行" />
          <el-option label="已完成" value="已完成" />
        </el-select>
      </el-form-item>

      <el-form-item>
        <el-button type="primary" @click="onSubmit">创建</el-button>
        <el-button @click="onCancel">取消</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
export default {
  data() {
    return {
      value: [],
      options: [
        {
          value: "重庆市公安局",
          label: "重庆市公安局",
          children: [
            {
              value: "shejiyuanze",
              label: "设计原则",
              children: [
                {
                  value: "yizhi",
                  label: "一致",
                },
                {
                  value: "fankui",
                  label: "反馈",
                },
                {
                  value: "xiaolv",
                  label: "效率",
                },
                {
                  value: "kekong",
                  label: "可控",
                },
              ],
            },
            {
              value: "daohang",
              label: "导航",
              children: [
                {
                  value: "cexiangdaohang",
                  label: "侧向导航",
                },
                {
                  value: "dingbudaohang",
                  label: "顶部导航",
                },
              ],
            },
          ],
        },
        {
          value: "万达广场",
          label: "万达广场",
          children: [
            {
              value: "basic",
              label: "Basic",
              children: [
                {
                  value: "layout",
                  label: "Layout 布局",
                },
                {
                  value: "color",
                  label: "Color 色彩",
                },
                {
                  value: "typography",
                  label: "Typography 字体",
                },
                {
                  value: "icon",
                  label: "Icon 图标",
                },
                {
                  value: "button",
                  label: "Button 按钮",
                },
              ],
            },
            {
              value: "form",
              label: "Form",
              children: [
                {
                  value: "radio",
                  label: "Radio 单选框",
                },
                {
                  value: "checkbox",
                  label: "Checkbox 多选框",
                },
                {
                  value: "input",
                  label: "Input 输入框",
                },
                {
                  value: "input-number",
                  label: "InputNumber 计数器",
                },
                {
                  value: "select",
                  label: "Select 选择器",
                },
                {
                  value: "cascader",
                  label: "Cascader 级联选择器",
                },
                {
                  value: "switch",
                  label: "Switch 开关",
                },
                {
                  value: "slider",
                  label: "Slider 滑块",
                },
                {
                  value: "time-picker",
                  label: "TimePicker 时间选择器",
                },
                {
                  value: "date-picker",
                  label: "DatePicker 日期选择器",
                },
                {
                  value: "datetime-picker",
                  label: "DateTimePicker 日期时间选择器",
                },
                {
                  value: "upload",
                  label: "Upload 上传",
                },
                {
                  value: "rate",
                  label: "Rate 评分",
                },
                {
                  value: "form",
                  label: "Form 表单",
                },
              ],
            },
            {
              value: "data",
              label: "Data",
              children: [
                {
                  value: "table",
                  label: "Table 表格",
                },
                {
                  value: "tag",
                  label: "Tag 标签",
                },
                {
                  value: "progress",
                  label: "Progress 进度条",
                },
                {
                  value: "tree",
                  label: "Tree 树形控件",
                },
                {
                  value: "pagination",
                  label: "Pagination 分页",
                },
                {
                  value: "badge",
                  label: "Badge 标记",
                },
              ],
            },
            {
              value: "notice",
              label: "Notice",
              children: [
                {
                  value: "alert",
                  label: "Alert 警告",
                },
                {
                  value: "loading",
                  label: "Loading 加载",
                },
                {
                  value: "message",
                  label: "Message 消息提示",
                },
                {
                  value: "message-box",
                  label: "MessageBox 弹框",
                },
                {
                  value: "notification",
                  label: "Notification 通知",
                },
              ],
            },
            {
              value: "navigation",
              label: "Navigation",
              children: [
                {
                  value: "menu",
                  label: "NavMenu 导航菜单",
                },
                {
                  value: "tabs",
                  label: "Tabs 标签页",
                },
                {
                  value: "breadcrumb",
                  label: "Breadcrumb 面包屑",
                },
                {
                  value: "dropdown",
                  label: "Dropdown 下拉菜单",
                },
                {
                  value: "steps",
                  label: "Steps 步骤条",
                },
              ],
            },
            {
              value: "others",
              label: "Others",
              children: [
                {
                  value: "dialog",
                  label: "Dialog 对话框",
                },
                {
                  value: "tooltip",
                  label: "Tooltip 文字提示",
                },
                {
                  value: "popover",
                  label: "Popover 弹出框",
                },
                {
                  value: "card",
                  label: "Card 卡片",
                },
                {
                  value: "carousel",
                  label: "Carousel 走马灯",
                },
                {
                  value: "collapse",
                  label: "Collapse 折叠面板",
                },
              ],
            },
          ],
        },
        {
          value: "ziyuan",
          label: "资源",
          children: [
            {
              value: "axure",
              label: "Axure Components",
            },
            {
              value: "sketch",
              label: "Sketch Templates",
            },
            {
              value: "jiaohu",
              label: "组件交互文档",
            },
          ],
        },
      ],
      customer_list: ["wef", "werfg", "yuj"],
      customer: null,
      search: null,
      form: {
        project_id: null,
        project_begindate: null,
        project_name: "",
        project_begindate: "",
        project_period: "建模",
        project_price: null,
        project_periodstage: "",
        project_type: "",
        project_state: "新建",
      },
      me:null,
    };
  },
  mounted() {
    this.form.project_begindate = Date.now();
    this.me = JSON.parse(localStorage.getItem("logindata")).employee;
  },
  methods: {
    onSubmit() {
      this.$axios
        .post("/all/newproject", {
          my_id:this.me.employee_id,
          my_name: this.me.employee_name,
          my_office:this.me.employee_office,
          project: this.form,
        })
        .then((resp) => {
          if (resp.data.state === "yes") this.$message.success("提交成功！");
          else {
            this.$message.error("提交失败！");
          }
        })
        .catch((e) => this.$message.error("提交失败！"));
    },
    onCancel() {
      this.$message({
        message: "已取消",
        type: "warning",
      });
    },
    search_client() {
      this.$axios.post("/all/search_client", this.value).then((resp) => {
        if (resp.data.state === "yes") this.$message.success("提交成功！");
        else {
          this.$message.error("提交失败！");
        }
      });
    },
  },
};
</script>

<style scoped>
.line {
  text-align: center;
}
</style>

