<template>
  <el-container>
    <el-form ref="form" :model="this.form" label-width="120px">
      <el-form-item label="客户单位">
        <el-cascader
          :disabled="this.root"
          :placeholder="value.toString()"
          v-model="value"
          :options="options"
          :props="{ expandTrigger: 'hover' }"
          @change="search_client"
          style="width: 300px"
        ></el-cascader>
      </el-form-item>

      <el-form-item label="客户名称">
        <el-select :placeholder="customer_name" v-model="customer_newid">
          <el-option
            v-for="item in customer_list"
            :key="item.client_id"
            :label="item.client_name"
            :value="item.client_id"
          >
          </el-option>
        </el-select>
      </el-form-item>

      <el-form-item label="项目编号">
        <el-input v-model="form.project_id" :disabled="this.root" />
      </el-form-item>
      <el-form-item label="项目名称">
        <el-input v-model="form.project_name" :disabled="this.root" />
      </el-form-item>
      <el-form-item label="创建日期">
        <el-col :span="11">
          <el-date-picker
            disabled
            v-model="form.project_begindate"
            type="date"
            style="width: 100%"
          />
        </el-col>
      </el-form-item>

      <el-form-item label="结束日期">
        <el-col :span="11">
          <el-date-picker
            v-model="form.project_enddate"
            type="date"
            style="width: 100%"
          />
        </el-col>
      </el-form-item>

      <el-form-item label="项目阶段">
        <el-select v-model="form.project_period" placeholder="请选择">
          <el-option label="建模" value="建模" />
          <el-option label="渲染" value="渲染" />
          <el-option label="后期" value="后期" />
        </el-select>
      </el-form-item>

      <el-form-item label="项目报价" :disabled="this.root">
        <el-input v-model="form.project_price" :disabled="this.root" />
      </el-form-item>
      <el-form-item label="项目类型">
        <el-select
          v-model="form.project_type"
          :disabled="this.root"
          placeholder="请选择"
        >
          <el-option label="楼盘效果图设计" value="楼盘效果图设计" />
          <el-option label="商场效果图设计" value="商场效果图设计" />
          <el-option label="车站效果图设计" value="车站效果图设计" />
          <el-option label="厂房效果图设计" value="厂房效果图设计" />
          <el-option label="其他效果图设计" value="其他效果图设计" />
        </el-select>
      </el-form-item>

      <el-form-item label="项目状态">
        <el-select v-model="form.project_state" placeholder="请选择">
          <el-option label="新建" value="新建" />
          <el-option label="正在执行" value="正在执行" />
          <el-option label="已完成" value="已完成" />
        </el-select>
      </el-form-item>

      <el-form-item label="修改意见">
        <el-input v-model="form.amendments"/>
      </el-form-item>

      <el-form-item label="项目员工信息">
        <el-table :data="selected_employee" border>
          <el-table-column prop="ep_office" label="身份" sortable>
          </el-table-column>

          <el-table-column prop="employee_name" label="姓名"> </el-table-column>

          <el-table-column prop="department" label="部门" sortable>
          </el-table-column>

          <el-table-column label="评价">
            <template slot-scope="scope">
              <el-rate v-model="scope.row.evaluate"></el-rate>
            </template>
          </el-table-column>

          <el-table-column label="操作">
            <template slot-scope="scope">
              <el-button
                type="danger"
                @click="del(scope.row.employee_id, scope.$index)"
                >删除</el-button
              >
            </template>
          </el-table-column>
        </el-table>
        <el-button type="success" @click="Add = true" size="mini"
          >添加员工</el-button
        >
      </el-form-item>
    </el-form>

    <el-dialog title="提示" :visible.sync="V" width="30%">
      <span>确定要提交吗?</span>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="alter">确 定</el-button>
        <el-button @click="V = false">取 消</el-button>
      </span>
    </el-dialog>

    <el-dialog title="添加员工" :visible.sync="Add" width="600px">
      <el-table
        :data="available_employee"
        tooltip-effect="dark"
        style="width: 100%"
        @selection-change="handleSelectionChange"
      >
        <el-table-column type="selection" width="55"></el-table-column>
        <el-table-column prop="employee_id" label="编号" sortable width="120">
        </el-table-column>
        <el-table-column prop="employee_name" label="姓名" sortable width="120">
        </el-table-column>
        <el-table-column
          prop="department"
          label="部门"
          sortable
          show-overflow-tooltip
        >
        </el-table-column>

        <el-table-column label="身份" width="150">
          <template slot-scope="scope">
            <el-select v-model="scope.row.ep_office" placeholder="请选择">
              <el-option label="新手" value="新手" />
              <el-option label="熟手" value="熟手" />
              <el-option label="模型主管" value="模型主管" />
              <el-option label="渲染主管" value="渲染主管" />
              <el-option label="后期主管" value="后期主管" />
            </el-select>
          </template>
        </el-table-column>
      </el-table>

      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="Add = false">确 定</el-button>
        <el-button @click="Add = false" type="primary">取 消</el-button>
      </div>
    </el-dialog>

    <el-footer style="text-align: center">
      <el-button type="primary" @click="V = true">确定</el-button>
      <el-button @click="back">返回</el-button>
    </el-footer>
  </el-container>
</template>


<script>
export default {
  data() {
    return {
      delemployee_id: null,
      V: false,
      root: true,
      me: null,
      value: ["Yiji"],
      options: null,
      customer_newid: null,
      customer_id: 7,
      customer_name: null,
      customer_list: [
        {
          client_id: 1,
          client_name: "ret",
          client_first: "gr",
          client_second: "qefgrgf",
          client_third: "ertgh",
          client_tele: "th",
        },
        {
          client_id: 2,
          client_name: "tyj",
          client_first: "ki",
          client_second: "",
          client_third: "",
          client_tele: "",
        },
      ],
      add_employees: [],
      del_employees: [],
      Add: false,
      form: {
        project_id: null,
        project_name: "",
        project_begindate: null,
        project_period: "",
        project_price: null,
        project_enddate: null,
        project_periodstage: "",
        project_type: "",
        project_state: "",
        amendments: "",
      },
      selected_employee: [
        {
          evaluate: 3,
          department: null,
          employee_id: 1,
          employee_name: "老王wdf",
          ep_office: "模型主管w",
        },
        {
          evaluate: 2,
          department: null,
          employee_id: 2,
          employee_name: "老王",
          ep_office: "模型主管",
        },
      ],
      available_employee: [
        {
          department: null,
          employee_id: 3,
          employee_name: "老王gevev",
        },
        {
          department: null,
          employee_id: 4,
          employee_name: "老ebnt王",
        },
      ],
    };
  },
  methods: {
    search_client() {
      this.$axios
        .post("/all/search_client", { value: this.value })
        .then((resp) => {
          this.customer_list = resp.data.customer_list;
        });
    },
    back() {
      this.Add = false;
      this.$router.push({ path: "/director/myproject" });
    },
    alter() {
      this.$axios
        .post("/all/project", {
          project: this.form,
          del_employees: ['693','3968'],
          add_employees: [
            {
              employee_id: '56',
              employee_name:'',
              employee_office:'新手',
              department:'',
              ep_office: "模型主管",
            },
            {
              employee_id: '48',
              employee_name:'',
              employee_office:'新手',
              department:'',
              ep_office: "新手",
            },
          ],
          client_id:
            this.customer_newid == null
              ? this.customer_id
              : this.customer_newid,
          my_id: this.me.employee_id,
          my_office: this.me.employee_office,
          my_name: this.me.employee_name,
        })
        .then((resp) => {
          if (resp.data.state === "yes") {
            this.$message.success("修改成功");
          } else {
            this.$message.error("修改失败");
          }
        })
        .catch((e) => {
          this.$message.error("失败");
        });
      this.V = false;
    },
    handleSelectionChange(val) {
      this.add_employees = val;
    },
    del(id, index) {
      this.del_employees.push(id);
      this.selected_employee.splice(index, 1);
    },
  },
  mounted() {
    this.form = JSON.parse(localStorage.getItem("project"));
    this.me = JSON.parse(localStorage.getItem("logindata")).employee;
    if (this.me.employee_office === "模型主管") {
      this.root = false;
    }
    this.$axios
      .post("/all/select_employee", {
        project_id: this.project_id,
        my_id: this.me.employee_id,
        my_name: this.me.employee_name,
        my_office: this.me.employee_office,
      })
      .then((resp) => {
        this.selected_employee = resp.selected_employee;
        this.available_employee = resp.available_employee;
      });

    this.$axios
      .post("all/project_client", {
        project_id: this.project_id,
        my_id: this.me.employee_id,
        my_office: this.me.employee_office,
        my_name: this.me.employee_name,
      })
      .then((resp) => {
        this.customer_name = resp.data.client_name;
        this.customer_id = resp.data.client_id;
        this.value = resp.data.value;
      });
  },
};
</script>