<template>
  <el-container>
    <el-main>
      <el-form ref="form" :model="form" label-width="120px" disabled>
        <el-form-item label="客户名称">
          <el-input v-model="form.customer" />
        </el-form-item>

        <el-form-item label="项目名称">
          <el-input v-model="form.project_name" />
        </el-form-item>

        <el-form-item label="创建日期">
          <el-col :span="11">
            <el-date-picker
              disabled
              v-model="form.project_begindate"
              type="date"
              style="width: 100%"
            />
          </el-col>
        </el-form-item>

        <el-form-item label="项目阶段">
          <el-select v-model="form.project_period" placeholder="请选择">
            <el-option label="建模" value="建模" />
            <el-option label="渲染" value="渲染" />
            <el-option label="后期" value="后期" />
          </el-select>
        </el-form-item>

        <el-form-item label="项目状态">
          <el-input v-model="form.project_state" disabled />
        </el-form-item>

        <el-form-item label="修改意见">
          <el-input v-model="form.amendments" />
        </el-form-item>

        <el-form-item label="我的评价">
          <el-rate
            style="margin-top: 10px"
            v-model="form.evaluate"
            disabled
          ></el-rate>
        </el-form-item>
      </el-form>
    </el-main>
    <el-footer style="text-align: center">
      <el-button type="primary" @click="back">返回</el-button>
    </el-footer>
  </el-container>
</template>


<script>
export default {
  data() {
    return {
      Add: false,
      form: {
        evaluate: 5,
        customer: null,
        project_id: null,
        project_name: "",
        project_begindate: null,
        project_period: "",
        project_price: null,
        project_enddate: null,
        project_periodstage: "",
        project_type: "",
        project_state: "",
        amendments: "",
      },
    };
  },
  methods: {
    back() {
      this.Add = false;
      this.$router.push({ path: "/employee/myproject" });
    },
  },
  mounted() {
    this.form = JSON.parse(localStorage.getItem("project"));
  },
};
</script>