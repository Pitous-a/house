<template>
  <lemon-imui
    width="100%"
    height="100vh"
    :user="this.user"
    ref="IMUI"
    @pull-messages="handlePullMessages"
    @change-contact="changesession"
    @send="handleSend"
  ></lemon-imui>
</template>

<script>
export default {
  data() {
    return {
      session: null,
      user: { id: null, displayName: null, avatar: "" },
      allmessages: [],
      allcontacts: [],
    };
  },
  beforeMount() {
    // 初始化表情包。
    // IMUI.initEmoji(...);
    // 从后端请求会话数据，包装成下面的样子
  },
  mounted() {
    console.log(1);
    var me = JSON.parse(localStorage.getItem("logindata")).employee;
    this.user = {
      id: me.employee_id,
      displayName: me.employee_name,
      avatar: "",
    };

    this.key = this.user.id;
    console.log(this.user);

    this.$axios
      .post("/allmessages", { employee_id: me.employee_id })
      .then((resp) => {
        console.log("43");
        console.log(this.user);

        console.log(resp.data.Sessionls);
        localStorage.setItem(
          "allcontacts",
          JSON.stringify(resp.data.Sessionls)
        );
        localStorage.setItem(
          "allmessages",
          JSON.stringify(resp.data.Messagels)
        );
        this.allcontacts = JSON.parse(localStorage.getItem("allcontacts"));
        this.allmessages = JSON.parse(localStorage.getItem("allmessages"));
        const { IMUI } = this.$refs;
        IMUI.initContacts(this.allcontacts);
        console.log("IMUI.initContacts(this.allcontacts);")
      });
  },
  methods: {
    changesession(contact) {
      console.log("changesession")
      console.log(contact)
      this.session = contact;
    },
    handlePullMessages(contact, next) {
      console.log("handlePullMessages(contact, next)")
      console.log(contact);
      var messages = [];
      for (let i = 0; i < this.allmessages.length; i++) {
        if (this.allmessages[i].id == contact.id) {
          messages = this.allmessages[i].messages;
          break;
        }
      }
      next(messages, true);
    },
    handleSend(message, next, file) {
      // ... 调用你的消息发送业务接口
      // setTimeout(() => {
      //   next();
      // }, 1000);
      // next(message,true)/
      //执行到next消息会停止转圈，如果接口调用失败，可以修改消息的状态 next({status:'failed'});
      // next({status:'failed'})
      console.log(86);
      console.log(this.session);
      this.$axios
        .post("/addmessage", {
          id: this.session.id,
          employee_id: this.user.id,
          status: "succeed",
          type: "text",
          content: message.content,
          time: Date.now(),
          user_name: this.user.displayName,
          avatar: this.user.avatar,
          // filesize:400,
          // filename:'',
        })
        .then((resp) => {
          console.log("98");
          console.log(this.key);
        })

        .catch((e) => {
          console.log(e);
        });
      next();
      // this.key += 1;
    },
  },
};
</script>

<style>
</style>
