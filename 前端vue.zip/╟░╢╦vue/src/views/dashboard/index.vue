<template>
  <body id="main">
    <div class="dashboard-container">
      <info></info>
    </div>
  </body>
</template>

<script>
import { mapGetters } from "vuex";
import info from "../other/info.vue";
export default {
  components: { info },
  name: "Dashboard",
  computed: {
    ...mapGetters(["name"]),
  },
};
</script>

<style lang="scss" scoped>
.dashboard {
  &-container {
    margin: 30px;
  }
  &-text {
    font-size: 30px;
    line-height: 46px;
  }
}
// #main{
//   background: url("../../icons/img/a.jpg") no-repeat center center;
//   background-size: cover;
//   width:100%;
// height:100%	;
// position:fixed;
// }
</style>
