<template>
  <el-container>
    <el-main>
      <el-descriptions class="margin-top" title="个人信息" :column="3" border>
        <template slot="extra">
          <!-- <el-button type="primary" size="small">操作</el-button> -->
        </template>
        <el-descriptions-item>
          <template slot="label">
            <i class="el-icon-user"></i>
            编号
          </template>
          {{ me.employee_id }}
        </el-descriptions-item>

        <el-descriptions-item>
          <template slot="label">
            <i class="el-icon-user"></i>
            姓名
          </template>
          {{ me.employee_name }}
        </el-descriptions-item>

        <el-descriptions-item>
          <template slot="label">
            <i class="el-icon-mobile-phone"></i>
            手机号
          </template>
          {{ me.employee_tele }}
        </el-descriptions-item>

        <el-descriptions-item>
          <template slot="label">
            <i class="el-icon-s-custom"></i>
            职务
          </template>
          {{ me.employee_office }}
        </el-descriptions-item>

        <el-descriptions-item>
          <template slot="label">
            <i class="el-icon-school"></i>
            部门
          </template>
          <el-tag>{{ me.department }}</el-tag>
        </el-descriptions-item>
      </el-descriptions>

      <div v-if="me.employee_office !== '老板'">
        <br />
        <span>项目进度</span><br /><br />
        <el-progress
          style="margin-left: 10%; margin-right: 10%"
          type="circle"
          :format="f1"
          :percentage="percent[0]"
        ></el-progress>

        <el-progress
          style="margin-left: 10%; margin-right: 10%"
          type="circle"
          :percentage="percent[1]"
          color="#f56c6c"
          :format="f2"
        ></el-progress>

        <el-progress
          style="margin-left: 10%; margin-right: 10%"
          type="circle"
          :percentage="percent[2]"
          color="#5cb87a"
          :format="f3"
        ></el-progress>
      </div>

      <div>
        <br />
        <span>操作记录</span>
        <br /><br />
        <el-timeline>
          <el-timeline-item
            v-for="(note, index) in notes"
            :key="index"
            :timestamp="note.operate_date"
          >
            {{ note.operate_what }}
          </el-timeline-item>
        </el-timeline>
      </div>
    </el-main>
  </el-container>
</template>

<script>
export default {
  data() {
    return {
      user: null,
      me: null,
      tableData: [
        {
          evaluate: 3,
          project_id: null,
          project_name: "",
          project_begindate: null,
          project_period: "",
          project_price: null,
          project_enddate: null,
          project_periodstage: "",
          project_type: "",
          project_state: "正在执行",
          amendments: "",
        },
        {
          evaluate: 3,
          project_id: 1,
          project_name: "cw",
          project_begindate: "2020-17-5",
          project_period: "",
          project_price: null,
          project_enddate: null,
          project_periodstage: "",
          project_type: "",
          project_state: "新建",
          amendments: "",
        },
        {
          evaluate: 3,
          project_id: 5,
          project_name: "csfb",
          project_begindate: "2021-17-5",
          project_period: "",
          project_price: null,
          project_enddate: null,
          project_periodstage: "",
          project_type: "",
          project_state: "新建",
          amendments: "",
        },
        {
          evaluate: 3,
          project_id: 5,
          project_name: "csfb",
          project_begindate: "2021-17-5",
          project_period: "",
          project_price: null,
          project_enddate: null,
          project_periodstage: "",
          project_type: "",
          project_state: "已完成",
          amendments: "",
        },
      ],
      value: [0, 0, 0],
      percent: [0, 0, 0],
      notes: [{}],
    };
  },
  methods: {
    f1(p) {
      return `正在执行\n${p}%`;
    },
    f2(p) {
      return `未完成\n${p}%`;
    },
    f3(p) {
      return `已完成\n${p}%`;
    },
  },
  beforeMount() {
    this.me = JSON.parse(localStorage.getItem("logindata")).employee;
    this.user = JSON.parse(localStorage.getItem("logindata")).user;
    if (this.me.employee_office !== "老板") {
      this.$axios
        .post("/employee/allproject", {
          employee_id: this.me.employee_id,
          employee_office: this.me.employee_office,
        })
        .then((resp) => {
          this.tableData = resp.data.allproject;
          let all = 0;
          for (let i in this.tableData) {
            all++;
            let x = this.tableData[i].project_state;
            if (x === "新建") this.value[0]++;
            else if (x === "正在执行") this.value[1]++;
            else this.value[2]++;
          }
          console.log(all);
          this.percent[0] = parseInt((this.value[0] / all) * 100);
          this.percent[1] = parseInt((this.value[1] / all) * 100);
          this.percent[2] = parseInt((this.value[2] / all) * 100);
        })
        .catch((e) => console.log("post失败"));
        
    }
    this.$axios
      .post("/all/notes", {
        employee_id: this.me.employee_id,
        employee_office: this.me.employee_office,
      })
      .then((resp) => {
        this.notes = resp.data.ls;
        console.log(this.notes);
      })
      .catch((e) => console.log("post失败"));
  },
};
</script>

<style>
.text {
  font-size: 14px;
}

.item {
  margin-bottom: 18px;
}

.clearfix:before,
.clearfix:after {
  display: table;
  content: "";
}
.clearfix:after {
  clear: both;
}

.box-card {
  width: 480px;
}
</style>