<template>
  <el-container>
    <el-form ref="form" :model="form" label-width="120px" style="width: 80%">
      <el-form-item label="员工编号">
        <el-input v-model="form.employee_id" />
      </el-form-item>
      <el-form-item label="员工姓名">
        <el-input v-model="form.employee_name" />
      </el-form-item>
      <el-form-item label="年龄">
        <el-input v-model="form.employee_age" />
      </el-form-item>
      <el-form-item label="部门">
        <el-select v-model="form.department" placeholder="请选择">
          <el-option label="主管部" value="主管部" />
          <el-option label="建模部" value="建模部" />
          <el-option label="渲染部" value="渲染部" />
          <el-option label="后期部" value="后期部" />
          <el-option label="办公室" value="办公室" />
        </el-select>
      </el-form-item>
      <el-form-item label="联系方式">
        <el-input v-model="form.employee_tele" />
      </el-form-item>

      <el-form-item label="职务">
        <el-select v-model="form.employee_office" placeholder="请选择">
          <el-option label="新手" value="新手" />
          <el-option label="熟手" value="熟手" />
          <el-option label="前台" value="前台" />
          <el-option label="模型主管" value="模型主管" />
          <el-option label="渲染主管" value="渲染主管" />
          <el-option label="后期主管" value="后期主管" />
          <el-option label="老板" value="老板" />
        </el-select>
      </el-form-item>
      <el-form-item label="个人能力">
        <el-rate
          v-model="form.employee_capability"
          style="margin-top: 10px"
        ></el-rate>
      </el-form-item>

      <el-form-item label="工作态度">
        <el-rate
          style="margin-top: 10px"
          v-model="form.employee_workattitude"
        ></el-rate>
      </el-form-item>

      <el-form-item label="账号">
        <el-input v-model="form.username" value="form.employee_name" />
      </el-form-item>

      <el-form-item label="密码">
        <el-input v-model="form.password" />
      </el-form-item>
    </el-form>

    <el-footer style="text-align: center">
      <el-button type="primary" @click="confirm_add">修改</el-button>
      <el-button @click="back">返回</el-button>
    </el-footer>
  </el-container>
</template>


<script>
export default {
  data() {
    return {
      form: {
        department: null,
        employee_age: null,
        employee_capability: null,
        employee_id: null,
        employee_name: null,
        employee_office: "模型主管",
        employee_tele: null,
        employee_workattitude: 4,
      },
    };
  },
  methods: {
    back() {
      this.$router.push({ path: "/boss2/allemployee" });
    },
    confirm_add() {
      this.$axios
        .post("/boss/alteremployee", this.form)
        .then((resp) => {
          if (resp.data.state === "yes") this.$message.success("提交成功");
          else {
            this.$message.error("提交失败");
          }
        })
        .catch((e) => this.$message.error("失败"));
    },
  },
  mounted() {
    this.form = JSON.parse(localStorage.getItem("employee"));
    let employee = JSON.parse(localStorage.getItem("logindata")).employee;
    this.form.my_id = employee.employee_id;
    this.form.my_name = employee.employee_name;
    this.form.my_office = employee.employee_office;
  },
};
</script>