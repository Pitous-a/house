<template>
  <div class="app-container">
    <el-form ref="form" :model="form" label-width="120px">
      <el-form-item label="客户姓名">
        <el-input v-model="form.client_name" />
      </el-form-item>
      <el-form-item label="客户单位">
        <el-input v-model="form.client_first" />
      </el-form-item>
      <el-form-item label="二级单位">
        <el-input v-model="form.client_second" />
      </el-form-item>
      <el-form-item label="三级单位">
        <el-input v-model="form.client_third" />
      </el-form-item>

      <el-form-item label="电话">
        <el-input v-model="form.client_tele" />
      </el-form-item>

      <el-form-item>
        <el-button type="primary" @click="onSubmit">确定</el-button>
        <el-button @click="onCancel">返回</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
export default {
  data() {
    return {
      form: {
        client_name: "",
        client_first: "",
        client_second: "",
        client_third: "",
        client_tele: "",
      },
    };
  },
  methods: {
    onSubmit() {
      this.$axios
        .post("/boss/alterclient", this.form)
        .then((resp) => {
          if (resp.data.state === "yes") this.$message.success("提交成功");
          else {
            this.$message.error("提交失败");
          }
        })
        .catch((e) => this.$message.error("失败"));
    },
    onCancel() {
      this.$router.push("/boss3/allclient");
    },
  },
  mounted() {
    this.form = JSON.parse(localStorage.getItem("client"));
    let employee = JSON.parse(localStorage.getItem("logindata")).employee;
    this.form.my_id = employee.employee_id;
    this.form.my_name = employee.employee_name;
    this.form.my_office = employee.employee_office;
  },
};
</script>

<style scoped>
.line {
  text-align: center;
}
</style>

