<template>
  <el-table
    :loading="loading"
    :data="
      tableData.filter(
        (data) =>
          !search ||
          data.project_name.toLowerCase().includes(search.toLowerCase())
      )
    "
    style="width: 100%"
  >
    <el-table-column label="创建日期" prop="project_begindate" sortable>
    </el-table-column>

    <el-table-column label="项目名称" prop="project_name" sortable>
    </el-table-column>

    <el-table-column label="项目状态" prop="project_state" sortable>
    </el-table-column>

    <el-table-column>
      <!-- <template slot="header" slot-scope="scope">
        <el-input v-model="search" size="mini" placeholder="输入关键字搜索" />
      </template> -->
      <template slot-scope="scope">
        <el-button size="mini" type="primary" @click="detail(scope.$index)">
          详细信息
        </el-button>

        <el-button size="mini" type="danger" @click="V = true">
          删除
        </el-button>

        <el-dialog title="提示" :visible.sync="V" width="30%">
          <span>确定要删除吗?</span>
          <span slot="footer" class="dialog-footer">
            <el-button type="primary" @click="del(scope.$index)"
              >确 定</el-button
            >
            <el-button @click="V = false">取 消</el-button>
          </span>
        </el-dialog>
      </template>
    </el-table-column>
  </el-table>
</template>

<script>
export default {
  data() {
    return {
      me: null,
      V: false,
      turn: true,
      loading: true,
      tableData: [
        {
          project_id: null,
          project_name: "",
          project_begindate: null,
          project_period: "",
          project_price: null,
          project_enddate: null,
          project_periodstage: "",
          project_type: "",
          project_state: "",
          amendments: "",
        },
        {
          project_id: 1,
          project_name: "cw",
          project_begindate: "2020-12-5",
          project_period: "",
          project_price: null,
          project_enddate: null,
          project_periodstage: "",
          project_type: "",
          project_state: "新建",
          amendments: "",
        },
        {
          project_id: 5,
          project_name: "csfb",
          project_begindate: "2021-12-5",
          project_period: "",
          project_price: null,
          project_enddate: null,
          project_periodstage: "",
          project_type: "",
          project_state: "新建",
          amendments: "",
        },
      ],
      search: "",
    };
  },
  methods: {
    detail(index) {
      this.$router.push({ path: "/boss1/project" });
      localStorage.setItem("project", JSON.stringify(this.tableData[index]));
      this.turn = true;
    },
    del(index) {
      this.$axios
        .post("/boss/delproject", {
          my_id: this.me.employee_id,
          my_name: this.me.employee_name,
          my_office: this.me.employee_office,
          project_id: this.tableData[index].project_id,
        })
        .then((resp) => {
          if (resp.data.state === "yes") {
            this.$message.success("删除成功");
          } else {
            this.$message.error("删除失败");
          }
        })
        .catch((e) => this.$message.error("失败"))
        this.V = false;
    },
  },
  mounted() {
    this.me = JSON.parse(localStorage.getItem("logindata")).employee;
    this.$axios
      .post("/all/allproject", {
        my_id: this.me.employee_id,
        my_name: this.me.employee_name,
        my_office: this.me.employee_office,
      })
      .then((resp) => {
        this.tableData = resp.data.allproject;
      })
      .catch((e) => console.log("post失败"));
  },
};
</script>
<style>
.demo-table-expand {
  font-size: 0;
}
.demo-table-expand label {
  width: 100px;
  color: #99a9bf;
}
.demo-table-expand .el-form-item {
  margin-right: 0;
  margin-bottom: 0;
  width: 50%;
}
</style>